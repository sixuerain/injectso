/* acconfig.h -- `autoheader' will generate config.h.in for injectso . */

/* Operating system we're being compiled on                            */
#undef OS_LINUX
#undef OS_SOLARIS

/* CPU we're being compiled on                                         */
#undef CPU_IA32
#undef CPU_SPARC

/* On Linux systems we need _XOPEN_SOURCE = 500 to get the prototype   */
/* for pread() from unistd.h                                           */
#undef _XOPEN_SOURCE
