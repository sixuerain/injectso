/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Operating system we're being compiled on                            */
#define OS_LINUX 1
/* #undef OS_SOLARIS */

/* CPU we're being compiled on                                         */
#define CPU_IA32 1
/* #undef CPU_SPARC */

/* On Linux systems we need _XOPEN_SOURCE = 500 to get the prototype   */
/* for pread() from unistd.h                                           */
#define _XOPEN_SOURCE 500

/* Define if you have the <procfs.h> header file.  */
/* #undef HAVE_PROCFS_H */
